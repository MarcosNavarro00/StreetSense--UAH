const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const cors = require('cors');
const admin = require('firebase-admin');
const serviceAccountMQTT = require('./server/auth/firebase_rtdb.json');
const serviceAccountPredictions = require('./server/auth/firebase_predictions.json');
require('dotenv').config();

const adminRTDB = admin.initializeApp({
    credential: admin.credential.cert(serviceAccountMQTT),
    databaseURL: process.env.FIREBASE_RTDB_URL
},"adminRTDB");

const adminPredictions = admin.initializeApp({
    credential: admin.credential.cert(serviceAccountPredictions),
},"adminPredictions");


const port = process.env.PORT || 3000;
const peatonRouter = require('./server/router/routesPeaton');
const cocheRouter = require('./server/router/routesCoche');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'dist')));
app.use((req, res, next) => {
    req.adminRTDB = adminRTDB;
    req.adminPredictions = adminPredictions;
    next();
});

app.use('/API/peatones/', peatonRouter);
app.use('/API/coches/', cocheRouter);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, () => console.log(`Server listening on port ${port}`));
