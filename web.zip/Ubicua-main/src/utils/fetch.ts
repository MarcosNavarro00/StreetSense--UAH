const backend = import.meta.env.VITE_APP_BACKEND_URL as string || 'http://localhost:3000';


export const getGraphData = (type:string, time:string) =>{
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    
    const requestOptions: RequestInit = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow' as RequestRedirect
    };
    
    return fetch(`${backend}/API/${type}/${time}`,requestOptions)
}


export const getPredictionData = (type:string,time:string) =>{
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    
    const requestOptions: RequestInit = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow' as RequestRedirect
    };
    
    return fetch(`${backend}/API/${type}/predicciones/${time}`,requestOptions)
}



