import React from 'react'
import '../App.css'

interface BottomBarProps {
  toggleType: (type: string) => void
}

const BottomBar:React.FC<BottomBarProps> = ({toggleType}) => {

  return (
    <div id="BottomBar" className='BottomBar'>
      <div className='BottomBar-Left'>
        <img 
          src='/assets/BottomBar_icon1.png'  
          className='BottomBarImage' 
          onClick={()=>{toggleType("peatones")}}/>
      </div> 
      <div className='BottomBar-Right'> 
        <img 
          src='/assets/BottomBar_icon2.png' 
          className='BottomBarImage'
          onClick={()=>{toggleType("coches")}}/>
      </div>
    </div>
  )
}

export default BottomBar