import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Label } from 'recharts';
import { getGraphData } from '../utils/fetch';

interface ChartProps {
  type: string,
  time: string,
}

const Chart:React.FC<ChartProps> = ({type,time}) => {

  const [data, setData] = useState<any>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [width, setWidth] = useState(window.innerWidth);
  const [axysTags, setAxysTags] = useState<any>([]);

  const handleResize = () => {
    if (window.innerWidth<500) {
      setWidth(window.innerWidth);
    } 
    else {
      setWidth(500);
    }
  };

  useEffect(() => {
    getGraphData(type,time)
      .then((res:any) => {
        if(res.status === 200){
          res.json().then((data:any) => {
            let axys = data.splice(-2, 2); 
            setData(data);
            setAxysTags(axys);
            setIsLoading(false);
          });
        }
      })
      .catch((err:any) => {
        console.log(err);
      });
    handleResize();
    window.addEventListener('resize', handleResize);

    // Limpiar el evento de redimensionamiento al desmontar el componente
    return () => window.removeEventListener('resize', handleResize);
    
  }, [type,time]);

  if(isLoading) return <div>Loading...</div>;
  else{
    console.log(data);  
    return (
      <div style={{ width: '100%' }}>
        <LineChart
          width={width}
          height={450}
          data={data}
          margin={{
            top: 5, right: 50, left: 20, bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name">
            <Label value={axysTags[0]} offset={0} position="insideBottom" />
          </XAxis>
          <YAxis dataKey="value">
            <Label value={axysTags[1]} angle={-90} position="insideLeft" />
          </YAxis>
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="value" stroke="#ed9ff5" activeDot={{ r: 8 }} name={axysTags[1]} />
        </LineChart>
      </div>
    );
  }

  
}

export default Chart;
