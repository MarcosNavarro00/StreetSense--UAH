import React, { useEffect } from 'react'
import { getPredictionData } from '../utils/fetch'

import "../App.css"

interface PredictionsProps {
  type: string,
}

const Predictions:React.FC<PredictionsProps> = ({type}) => {

  const [dailyPrediction, setDailyPrediction] = React.useState<number>(0)
  const [weeklyPrediction, setWeeklyPrediction] = React.useState<number>(0)
  const [isLoading, setIsLoading] = React.useState<boolean>(true)

  useEffect(() => {
    setIsLoading(true)
    getPredictionData(type,"hoy").then((res) =>{
      if(res.status === 200){
        res.json().then((data) => {
          setDailyPrediction(data)
        })
      }
      else{
        setDailyPrediction(-1)
      }
      })
    getPredictionData(type,"semana").then((res) => {
      if(res.status === 200){
        res.json().then((data) => {
          setWeeklyPrediction(data)
        })
      }
      else{
        setWeeklyPrediction(-1)
      }
    })
    setIsLoading(false)
  }, [type])

  if(isLoading) return (
    <div className="Cards">
      <div className="Card">
        <h2>Probabilidad de tráfico diaria:</h2>
        <p id="prediction-value">Cargando...</p>
      </div>
      <div className="Card">
        <h2>Probabilidad de tráfico semanal</h2>
        <p id="prediction-value">Cargando...</p>
      </div>
    </div>
  )

  else{
    
    return (
      <div className="Cards">
        <div className="Card">
          <h2>Probabilidad de tráfico diaria:</h2>
          <p id="prediction-value">{dailyPrediction}</p>
        </div>
        <div className="Card">
          <h2>Probabilidad de tráfico semanal</h2>
          <p id="prediction-value">{weeklyPrediction}</p>
        </div>
      </div>
    )
  }
 
}

export default Predictions