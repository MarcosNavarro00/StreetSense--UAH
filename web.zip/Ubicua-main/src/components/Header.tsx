import '../App.css'

interface HeaderProps {
    type: string,
}

const Header:React.FC<HeaderProps> = ({type}) => {
    console.log(type);
    return (
        <div id="Header" className='Header'>
            <div className='Header-rectangle'></div>
            <p>{"Tráfico " + type}</p>
        </div>
      )
}

export default Header