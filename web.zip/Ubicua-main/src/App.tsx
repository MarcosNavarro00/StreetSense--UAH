import React, { useEffect } from 'react'
import BottomBar from './components/BottomBar'
import './App.css'
import Header from './components/Header'
import Loading from './pages/Loading'
import Menu from './pages/Menu'

const App = () => {

  const [loading, setLoading] = React.useState(true)
  const [type, setType] = React.useState<string>("peatones")

  const toggleType = (new_type: string) => {
    if( type != new_type){
      setType(new_type)
      setLoading(true)
    }
  }

  useEffect(() => {
    setTimeout(() => {
      setLoading(false)
    }, 1000)
  }, [type])

  if (loading) {
    return (
      <div id="App">
        <Loading/>
      </div>
    )
  }

  else{
    return (
      <div id="App" className='loaded'>
        <Header type={type}/>
        <Menu type = {type}/>
        <BottomBar toggleType={toggleType} />
      </div>
    )
  }
}

export default App