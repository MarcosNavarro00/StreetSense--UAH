import Chart from '../components/Chart'
import React, {useState} from 'react'
import "../App.css"
import Predictions from '../components/Predictions'

interface MenuProps {
  type: string,
}

const Menu:React.FC<MenuProps> = ({type}) => {

  const [time, setTime] = useState<string>("por_dia")

  const handleTime = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setTime(e.target.value)
  }

  return (
    <div className='Menu'>
      <div className="select-container">
        <select className="select-style" onChange={handleTime}>
            <option value="por_dia">Diario</option>
            <option value="por_semana">Semanal</option>
            <option value="por_mes">Mensual</option>
        </select>
      </div>
      <Chart type={type} time={time}/>
      <Predictions  type={type} />
    </div>
  )
}

export default Menu