import "./pages.css"

export const Loading = () => {
  return (
    <div style = {{margin: "0", padding: "0", display: "flex",minHeight: "100vh",alignItems: "center",justifyContent: "center",backgroundColor: "#fff",flexDirection: "column"}}>
        <div className="body">
            <div className="front wheel"></div>
            <div className="back wheel"></div>
        </div>
        
        <div className="cover">
            <div className="path"></div>
        </div>
        <div className="text">Cargando...</div>
    </div>
  )
}

export default Loading