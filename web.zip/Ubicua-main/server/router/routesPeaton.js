const admin = require('firebase-admin');
const express = require('express');
const moment = require('moment');
const router = express.Router();



router.get('/por_dia',(req, res) => {
    try{
        let dias = { 'L':0, 'M':0, 'X':0, 'J':0, 'V':0, 'S':0, 'D':0 };
        let semana_actual = moment().week();
        const ref = req.adminRTDB.database().ref('Paso de Peatones');
        ref.once('value', (snapshot) => {
            const data = snapshot.val();
            for(let key in data) {
                if(moment(data[key].Fecha).week() != semana_actual) continue;
                let fecha = moment(data[key].Fecha);
                let dia = fecha.format('d');
                switch (dia) {
                    case '1': dias.L++; break;
                    case '2': dias.M++; break;
                    case '3': dias.X++; break;
                    case '4': dias.J++; break;
                    case '5': dias.V++; break;
                    case '6': dias.S++; break;
                    case '0': dias.D++; break;
                }
            }
            let diasArray = [];
            for (let dia in dias) {
                diasArray.push({ name: dia, value: dias[dia] });
            }
            diasArray.push("días", "peatones")
            res.json(diasArray);
        }).catch((error) => {
            res.json({ error: error.message });
        });
    }
    catch(error){
        res.json({ error: error.message });
    }
});


router.get('/por_semana', (req, res) => {
    try {
        let semanas = { '1':0, '2':0, '3':0, '4':0, '5':0 };
        let mes_actual = moment().format('M');
        const ref = req.adminRTDB.database().ref('Paso de Peatones');
        ref.once('value', (snapshot) => {
            const data = snapshot.val();
            for(let key in data) {
                if(moment(data[key].Fecha).format('M') != mes_actual) continue;
                let fecha = moment(data[key].Fecha);
                let semana = fecha.week();
                if (semana >= 1 && semana <= 7) semanas['1']++;
                else if (semana >= 8 && semana <= 14) semanas['2']++;
                else if (semana >= 15 && semana <= 21) semanas['3']++;
                else if (semana >= 22 && semana <= 28) semanas['4']++;
                else semanas['5']++;
            }
            let semanasArray = [];
            for (let semana in semanas) {
                semanasArray.push({ name: semana, value: semanas[semana] });
            }
            semanasArray.push("semanas", "peatones")
            res.json(semanasArray);
        }).catch((error) => {
            res.json({ error: error.message });
        });
    } catch(error) {
        res.json({ error: error.message });
    }
});

router.get('/por_mes', (req, res) => {
    try {
        let meses = {
            'Ene':0, 'Feb':0, 'Mar':0, 'Abr':0, 
            'May':0, 'Jun':0, 'Jul':0, 'Ago':0, 
            'Sep':0, 'Oct':0, 'Nov':0, 'Dic':0
        };
        const ref = req.adminRTDB.database().ref('Paso de Peatones');
        ref.once('value', (snapshot) => {
            const data = snapshot.val();
            for(let key in data) {
                let fecha = moment(data[key].Fecha);
                let mes = fecha.format('M');
                switch (mes) {
                    case '1': meses.Ene++; break;
                    case '2': meses.Feb++; break;
                    case '3': meses.Mar++; break;
                    case '4': meses.Abr++; break;
                    case '5': meses.May++; break;
                    case '6': meses.Jun++; break;
                    case '7': meses.Jul++; break;
                    case '8': meses.Ago++; break;
                    case '9': meses.Sep++; break;
                    case '10': meses.Oct++; break;
                    case '11': meses.Nov++; break;
                    case '12': meses.Dic++; break;
                }
            }
            let mesesArray = [];
            for (let mes in meses) {
                mesesArray.push({ name: mes, value: meses[mes] });
            }
            mesesArray.push("meses", "peatones")
            res.json(mesesArray);
        }).catch((error) => {
            res.json({ error: error.message });
        });
    } catch(error) {
        res.json({ error: error.message });
    }
});

router.get('/predicciones/hoy', (req, res) => {
    try {
        let hoy= moment().startOf('day');
        let manana = moment(hoy).add(1, 'day');
        let transitadoValues = [];
        const prediccionPeatonesRef = req.adminPredictions.firestore().collection('PrediccionPeatones');
    
        prediccionPeatonesRef
        .where('fecha', '>=', hoy.toDate())
        .where('fecha', '<', manana.toDate())
        .get()
        .then((snapshot) => {
            if (snapshot.empty) {
                res.json({ error: 'No matching documents.' });
                return;
            }
            snapshot.forEach(doc => {
                transitadoValues.push(doc.data().prediccionDia.Transitado);
            });
            const transitado = Math.round(transitadoValues.reduce((a, b) => a + b, 0)/transitadoValues.length*100).toString()+"%"
            res.json(transitado);
        })
    }
    catch(error) {
        console.log(error);
        res.json({ error: error.message });
    }
});

router.get('/predicciones/semana', (req, res) => {
    try {
        let hoy= moment().startOf('day');
        let ultimo_dia = moment(hoy).add(7, 'day');
        let transitadoValues = [];
        const prediccionPeatonesRef = req.adminPredictions.firestore().collection('PrediccionPeatones');

        prediccionPeatonesRef
        .where('fecha', '>=', hoy.toDate())
        .where('fecha', '<', ultimo_dia.toDate())
        .get()
        .then((snapshot) => {
            if (snapshot.empty) {
                res.json({ error: 'No matching documents.' });
                return;
            }
            snapshot.forEach(doc => {
            doc.data().Semana.forEach(doc => {
                transitadoValues.push(doc.Transitado);
            })});
            const transitado = Math.round(transitadoValues.reduce((a, b) => a + b, 0)/transitadoValues.length*100).toString()+"%"
            res.json(transitado);
        })
    }
    catch(error) {
        console.log(error);
        res.json({ error: error.message });
    }
});

    




module.exports = router;
