/// <reference types="vite/client" />

interface ImportMeta {
    env: Record<string, unknown>;
}
